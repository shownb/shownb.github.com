On Error Resume Next
Const OLECMDID_PRINT = 6
Const OLECMDEXECOPT_DONTPROMPTUSER = 2
Set ie = CreateObject("InternetExplorer.Application")

'Do While ie.ReadyState <> 4
'    WScript.Sleep 1000
'Loop

Set fso=CreateObject("Scripting.FileSystemObject")
Set fs=fso.getfolder(".").files
For each f in fs
	If Right(f,4)="html" Then
		ie.Navigate f
		ie.Visible = 1
		ie.ExecWB 6,2
		WScript.Sleep 5000
	End If
next
'oIExplorer.ExecWB OLECMDID_PRINT, OLECMDEXECOPT_DONTPROMPTUSER